import { HomePage } from "./Pages/HomePage"
import { SinglePhoto } from "./Pages/SinglePhoto"
import { CustomRoute } from "./routes/CustomRoute"



 const App = () => <CustomRoute/>

export default App